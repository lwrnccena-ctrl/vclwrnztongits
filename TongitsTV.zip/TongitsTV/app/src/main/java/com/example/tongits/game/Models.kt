package com.example.tongits.game

// ---------- Cards ----------

enum class Suit(val symbol: String) { SPADES("♠"), HEARTS("♥"), DIAMONDS("♦"), CLUBS("♣") }

/** Ace is low only (A-2-3 is a run, Q-K-A is not). J/Q/K are worth 10. */
enum class Rank(val label: String, val order: Int, val points: Int) {
    ACE("A", 1, 1), TWO("2", 2, 2), THREE("3", 3, 3), FOUR("4", 4, 4), FIVE("5", 5, 5),
    SIX("6", 6, 6), SEVEN("7", 7, 7), EIGHT("8", 8, 8), NINE("9", 9, 9), TEN("10", 10, 10),
    JACK("J", 11, 10), QUEEN("Q", 12, 10), KING("K", 13, 10)
}

data class Card(val rank: Rank, val suit: Suit) {
    val points: Int get() = rank.points
    override fun toString() = rank.label + suit.symbol
}

fun fullDeck(): List<Card> = Suit.values().flatMap { s -> Rank.values().map { Card(it, s) } }

// ---------- Melds ----------

/** A set (3-4 of a kind) or a run (3+ in a row, same suit). */
data class Meld(val cards: List<Card>) {
    val isSet: Boolean get() = cards.all { it.rank == cards[0].rank }

    fun canSapaw(card: Card): Boolean = isValid(cards + card)

    companion object {
        fun isValid(cs: List<Card>): Boolean {
            if (cs.size < 3 || cs.distinct().size != cs.size) return false
            if (cs.all { it.rank == cs[0].rank }) return true // distinct cards => distinct suits
            if (cs.any { it.suit != cs[0].suit }) return false
            return cs.map { it.rank.order }.sorted().zipWithNext().all { (a, b) -> b - a == 1 }
        }

        fun of(cs: List<Card>): Meld {
            require(isValid(cs)) { "Invalid meld: $cs" }
            val sorted = if (cs.all { it.rank == cs[0].rank }) cs.sortedBy { it.suit.ordinal }
            else cs.sortedBy { it.rank.order }
            return Meld(sorted)
        }
    }
}

/** Best set of non-overlapping melds in a hand (most points melded). Also used by the BEST sort button. */
fun bestMelds(hand: List<Card>): List<List<Card>> {
    val cand = ArrayList<List<Card>>()
    hand.groupBy { it.rank }.values.forEach { g ->
        if (g.size == 3) cand.add(g)
        if (g.size == 4) {
            cand.add(g)
            g.indices.forEach { i -> cand.add(g.filterIndexed { j, _ -> j != i }) }
        }
    }
    hand.groupBy { it.suit }.values.forEach { g ->
        val s = g.sortedBy { it.rank.order }
        for (i in s.indices) for (j in i + 2 until s.size) {
            val run = s.subList(i, j + 1)
            if (run.zipWithNext().all { (a, b) -> b.rank.order - a.rank.order == 1 }) cand.add(run.toList())
        }
    }
    var best: List<List<Card>> = emptyList()
    var bestV = -1
    val used = HashSet<Card>()
    fun dfs(from: Int, chosen: List<List<Card>>, v: Int) {
        if (v > bestV) { bestV = v; best = chosen }
        for (k in from until cand.size) {
            val m = cand[k]
            if (m.any { it in used }) continue
            used.addAll(m)
            dfs(k + 1, chosen + listOf(m), v + m.sumOf { it.points })
            used.removeAll(m.toSet())
        }
    }
    dfs(0, emptyList(), 0)
    return best
}

/** Points left over after the best in-hand combos are set aside (the "Hand's Value"). */
fun deadwoodPoints(hand: List<Card>): Int =
    hand.sumOf { it.points } - bestMelds(hand).sumOf { m -> m.sumOf { it.points } }

// ---------- Players ----------

class PlayerState(val name: String, val isHuman: Boolean = false) {
    val hand = mutableListOf<Card>()
    val melds = mutableListOf<Meld>()

    /** Set when someone sapaws this player's meld: they can no longer fight. */
    var burned = false

    val canFight: Boolean get() = melds.isNotEmpty() && !burned

    fun handPoints(): Int = deadwoodPoints(hand)
}

// ---------- Game flow ----------

enum class Phase { DRAW, ACT, GAME_OVER }

enum class ResultKind { TONGITS, FIGHT, FIGHT_ALL_FOLDED, STOCK_EMPTY }

data class GameResult(val winner: Int, val kind: ResultKind, val points: List<Int>)

sealed interface Action {
    object DrawStock : Action
    data class TakeDiscard(val using: List<Card>) : Action
    data class MeldCards(val cards: List<Card>) : Action
    data class Sapaw(val card: Card, val targetPlayer: Int, val meldIndex: Int) : Action
    data class Discard(val card: Card) : Action
    object CallFight : Action
}

sealed interface GameEvent {
    data class Dealt(val player: Int, val card: Card) : GameEvent
    data class Drew(val player: Int, val card: Card, val fromDiscard: Boolean) : GameEvent
    data class Melded(val player: Int, val meld: Meld) : GameEvent
    data class Sapawed(val player: Int, val target: Int, val meldIndex: Int, val card: Card) : GameEvent
    data class Discarded(val player: Int, val card: Card) : GameEvent
    data class FightCalled(val player: Int, val challengers: List<Int>) : GameEvent
    data class TurnChanged(val player: Int) : GameEvent
    data class GameOver(val result: GameResult) : GameEvent
}
