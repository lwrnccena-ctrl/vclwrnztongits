package com.example.tongits.game

import kotlin.math.abs

/**
 * Returns ONE action at a time so the UI can animate each step and add
 * "thinking" delays between them.
 */
object TongitsAi {

    fun chooseAction(engine: TongitsEngine, index: Int): Action {
        val me = engine.players[index]
        return when (engine.phase) {
            Phase.DRAW -> chooseDraw(engine, me)
            Phase.ACT -> chooseAct(engine, me, index)
            Phase.GAME_OVER -> error("Game is over")
        }
    }

    /** Fight response: challenge when our own hand is already light. */
    fun wantsToChallenge(me: PlayerState): Boolean = me.handPoints() <= 14

    private fun chooseDraw(engine: TongitsEngine, me: PlayerState): Action {
        if (me.canFight && me.handPoints() <= 7) return Action.CallFight
        val top = engine.topDiscard
        if (top != null) {
            for (k in 2..3) {
                val using = me.hand.combinations(k).firstOrNull { Meld.isValid(it + top) }
                if (using != null) return Action.TakeDiscard(using)
            }
        }
        return Action.DrawStock
    }

    private fun chooseAct(engine: TongitsEngine, me: PlayerState, index: Int): Action {
        // 1. Expose the most valuable meld we hold.
        val best = (3..4).flatMap { k -> me.hand.combinations(k).filter { Meld.isValid(it) }.toList() }
            .maxByOrNull { m -> m.sumOf { it.points } }
        if (best != null) return Action.MeldCards(best)

        // 2. Sapaw onto any exposed meld (ours or theirs).
        for (card in me.hand) {
            for ((p, player) in engine.players.withIndex()) {
                for ((i, meld) in player.melds.withIndex()) {
                    if (meld.canSapaw(card)) return Action.Sapaw(card, p, i)
                }
            }
        }

        // 3. Discard the heaviest card that helps us least.
        val card = me.hand.maxByOrNull { c -> c.points - 4 * synergy(c, me.hand) }!!
        return Action.Discard(card)
    }

    private fun synergy(c: Card, hand: List<Card>): Int {
        val others = hand.filter { it != c }
        return others.count { it.rank == c.rank } +
            others.count { it.suit == c.suit && abs(it.rank.order - c.rank.order) in 1..2 }
    }
}

internal fun <T> List<T>.combinations(k: Int): Sequence<List<T>> {
    val src = this
    return sequence {
        if (k == 0) {
            yield(emptyList())
        } else {
            for (i in src.indices) {
                for (rest in src.drop(i + 1).combinations(k - 1)) {
                    yield(listOf(src[i]) + rest)
                }
            }
        }
    }
}
