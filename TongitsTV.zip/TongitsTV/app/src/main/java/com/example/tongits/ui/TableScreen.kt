package com.example.tongits.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.lerp
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.tongits.audio.SoundFx
import com.example.tongits.game.*
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

private val Gold = Color(0xFFF2C14E)
private val Cream = Color(0xFFF6EBCB)
private val Ink = Color(0xFF1B1B1B)

/** Everything is laid out in a 1920x1080 design space and scaled to fit the TV. */
@Composable
fun TableScreen(vm: TableViewModel = viewModel(), onQuit: () -> Unit = {}) {
    val s = vm.state
    BackHandler(enabled = s.showDumped) { s.showDumped = false }
    BoxWithConstraints(Modifier.fillMaxSize().background(Color(0xFF080506))) {
        val scale = minOf(maxWidth.value / 1920f, maxHeight.value / 1080f)
        Box(
            Modifier.align(Alignment.Center).requiredSize(1920.dp, 1080.dp)
                .graphicsLayer { scaleX = scale; scaleY = scale }
        ) {
            // While any overlay is open, nothing underneath can take D-pad focus.
            val locked = s.result != null || s.challenge != null || s.showDumped
            Box(Modifier.fillMaxSize().focusProperties { canFocus = !locked }) {
                Backdrop(s)
                Hud(vm, onQuit)
                val slots = s.slots()
                for (sp in s.sprites.values.toList()) key(sp.card) {
                    val slot = slots[sp.card]
                    if (slot != null) {
                        val click: (() -> Unit)? = if (sp.zone == Zone.InHand(s.human)) ({ vm.toggle(sp.card) }) else null
                        SpriteCard(sp, slot, sp.card in s.selected, click)
                    }
                }
            }
            Banner(s)
            DumpedOverlay(s)
            ChallengeOverlay(vm)
            ResultOverlay(vm)
        }
    }
}

// ---------------------------------------------------------------- helpers

private fun at(x: Float, y: Float, w: Float? = null, h: Float? = null): Modifier {
    val m = Modifier.offset(x.dp, y.dp)
    return if (w != null && h != null) m.size(w.dp, h.dp) else if (w != null) m.width(w.dp) else m
}

@Composable
private fun Txt(
    text: String, size: Float, color: Color = Cream, weight: FontWeight = FontWeight.Bold,
    serif: Boolean = false, spacing: Float = 0f, center: Boolean = false, modifier: Modifier = Modifier,
) {
    BasicText(
        text, modifier,
        style = TextStyle(
            color = color, fontSize = size.sp, fontWeight = weight,
            fontFamily = if (serif) FontFamily.Serif else FontFamily.Default,
            letterSpacing = spacing.sp, textAlign = if (center) TextAlign.Center else TextAlign.Start,
        ),
    )
}

@Composable
private fun Panel(x: Float, y: Float, w: Float, h: Float, brush: Brush, border: Color? = null, a: Float = 1f) {
    Box(
        at(x, y, w, h).alpha(a).background(brush)
            .then(if (border != null) Modifier.border(2.dp, border) else Modifier)
    )
}

@Composable
private fun TvButton(
    label: String, modifier: Modifier, enabled: Boolean = true, active: Boolean = false,
    fontSp: Float = 24f, focusable: Boolean = true, onClick: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier.alpha(if (enabled) 1f else 0.4f).clip(shape)
            .background(if (active) Gold else Color(0xFF2A2A2A))
            .border(if (focused) 5.dp else 3.dp, if (focused) Color.White else Color(0xFF7A6A3A), shape)
            .then(if (focusable) Modifier else Modifier.focusProperties { canFocus = false })
            .onFocusChanged { focused = it.isFocused }
            .clickable(enabled = enabled) { SoundFx.click(); onClick() },
        contentAlignment = Alignment.Center,
    ) { Txt(label, fontSp, if (active) Ink else Cream, FontWeight.Black) }
}

// ---------------------------------------------------------------- table

@Composable
private fun Backdrop(s: TableState) {
    val edge = Color(0xFF7A1F44)
    Panel(0f, 210f, 1920f, 190f, Brush.verticalGradient(listOf(Color(0xFF2A0716), Color(0xFF4A0F2A))), edge)
    Panel(0f, 400f, 1920f, 280f, Brush.radialGradient(listOf(Color(0xFFE0206A), Color(0xFF8E0F45), Color(0xFF3A0620))), edge)
    Panel(0f, 680f, 1920f, 320f, Brush.verticalGradient(listOf(Color(0xFF06210F), Color(0xFF0D4A22), Color(0xFF06210F))), Color(0xFF1E7A2E))
    Panel(0f, 1000f, 1920f, 80f, SolidColor(Color(0xFF120A0C)))

    val live = s.result == null
    val g1 by animateFloatAsState(if (live && s.turn == 1) 1f else 0f, label = "g1")
    val g2 by animateFloatAsState(if (live && s.turn == 2) 1f else 0f, label = "g2")
    val gh by animateFloatAsState(if (live && s.turn == s.human && s.revealed) 1f else 0f, label = "gh")
    val blue = SolidColor(Color(0x553B82F6))
    Panel(0f, 210f, 960f, 190f, blue, a = g1)
    Panel(960f, 210f, 960f, 190f, blue, a = g2)
    Box(at(4f, 212f, 952f, 186f).alpha(g1).border(8.dp, Color(0xFF3B82F6)))
    Box(at(964f, 212f, 952f, 186f).alpha(g2).border(8.dp, Color(0xFF3B82F6)))
    Box(at(6f, 682f, 1908f, 316f).alpha(gh).border(8.dp, Color(0xFFF28C28)))

    Avatar(40f, 24f, "R", "AI Rico", s.handOf(1).size, g1)
    Avatar(1784f, 24f, "B", "AI Bea", s.handOf(2).size, g2)

    Box(
        at(865f, 10f, 190f, 190f).clip(CircleShape)
            .background(Brush.verticalGradient(listOf(Color(0xFFF7D774), Color(0xFFB8860B))))
            .padding(10.dp).clip(CircleShape).background(Color(0xFF1A1A1A)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Txt("PRACTICE", 20f, center = true)
            Txt("ROUND", 26f, Gold, FontWeight.Black, serif = true)
            Txt("1", 64f, Color.White, FontWeight.Black, serif = true)
        }
    }

    // LWRNZ CASINO sits at the exact center; the deck and discards are drawn on top of it.
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Txt("LWRNZ CASINO", 64f, Gold, FontWeight.Black, serif = true, spacing = 10f, modifier = Modifier.offset(y = 1.dp))
    }

    Box(at(1400f, 470f, 460f, 140f).background(Color(0xFF1A0710)).border(3.dp, edge), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Txt("HITTER’S POT", 28f, Gold, FontWeight.Black, serif = true)
            Txt("300", 60f, Gold, FontWeight.Black)
        }
    }
}

@Composable
private fun Avatar(x: Float, y: Float, initial: String, name: String, cards: Int, glow: Float) {
    Box(
        at(x, y, 96f, 96f).background(Color(0xFF2B3A67)).border((3 + 3 * glow).dp, Gold),
        contentAlignment = Alignment.Center,
    ) { Txt(initial, 44f, Cream, FontWeight.Black, serif = true) }
    Txt(name, 22f, Gold, center = true, modifier = at(x - 12f, y + 102f, 120f))
    Txt("$cards cards", 18f, center = true, modifier = at(x - 12f, y + 130f, 120f))
}

@Composable
private fun Hud(vm: TableViewModel, onQuit: () -> Unit) {
    val s = vm.state
    val myTurn = s.turn == s.human && s.result == null && s.challenge == null && s.revealed
    val draw = myTurn && s.phase == Phase.DRAW
    val act = myTurn && s.phase == Phase.ACT
    val mine = s.handOf(s.human).map { it.card }
    val value = if (s.revealed && s.sort == SortMode.BEST) deadwoodPoints(mine) else mine.sumOf { it.points }

    StockPile(s.stockCount, draw) { vm.draw() }
    DiscardPile(s)

    TvButton("FIGHT", at(36f, 716f, 180f, 76f), draw, fontSp = 28f, focusable = false) { vm.fight() }
    Txt("Hold OK = FIGHT", 18f, Gold, center = true, modifier = at(36f, 918f, 180f))
    TvButton("QUIT", at(36f, 830f, 180f, 76f), fontSp = 28f) { onQuit() }

    Txt("YOU", 26f, Gold, modifier = at(40f, 1030f))
    Txt("9,800 chips      0 coins", 30f, modifier = at(130f, 1022f))
    TvButton("2 · DRAW", at(924f, 1009f, 180f, 62f), draw) { vm.draw() }
    TvButton("3 · TAKE", at(1118f, 1009f, 180f, 62f), draw && s.dumped.isNotEmpty()) { vm.take() }
    TvButton("4 · MELD", at(1312f, 1009f, 180f, 62f), act) { vm.meld() }
    TvButton("5 · SAPAW", at(1506f, 1009f, 180f, 62f), act) { vm.sapaw() }
    TvButton("6 · DISCARD", at(1700f, 1009f, 180f, 62f), act, fontSp = 20f) { vm.discard() }

    Txt("HAND’S VALUE", 26f, Gold, center = true, modifier = at(1580f, 700f, 304f))
    Txt("$value", 88f, Gold, FontWeight.Black, center = true, modifier = at(1580f, 730f, 304f))
    Txt("Press 1 to change sort", 20f, Gold, center = true, modifier = at(1580f, 922f, 304f))
    listOf(SortMode.BEST to "BEST", SortMode.SUITS to "SUITS", SortMode.RANKS to "RANKS").forEachIndexed { i, (m, label) ->
        TvButton(label, at(1580f + i * 104f, 850f, 94f, 62f), active = s.sort == m, fontSp = 20f, focusable = false) { s.sort = m; s.fresh.clear() }
    }
}

@Composable
private fun StockPile(count: Int, enabled: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        at(832f, 449f, 130f, 182f).zIndex(1f)
            .border(if (focused) 5.dp else 0.dp, Color.White, RoundedCornerShape(9.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(enabled = enabled) { SoundFx.click(); onClick() },
    ) {
        CardBack(130f)
        Box(
            Modifier.align(Alignment.TopStart).offset((-32).dp, 50.dp).size(56.dp, 40.dp)
                .clip(RoundedCornerShape(10.dp)).background(Color(0xFF1E7A2E)).border(3.dp, Gold, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
        ) { Txt("$count", 24f, Color.White, FontWeight.Black) }
    }
}

@Composable
private fun DiscardPile(s: TableState) {
    var focused by remember { mutableStateOf(false) }
    Box(
        at(950f, 435f, 186f, 210f).zIndex(1f)
            .border(if (focused) 4.dp else 0.dp, Gold, RoundedCornerShape(14.dp))
            .focusProperties { canFocus = false }
            .onFocusChanged { focused = it.isFocused }
            .clickable { SoundFx.click(); s.showDumped = true },
    )
    Txt("Dumped: ${s.dumped.size}  ·  press 0 to view", 20f, center = true, modifier = at(849f, 648f, 240f))
}

@Composable
private fun Banner(s: TableState) {
    val b = s.banner ?: return
    Box(Modifier.zIndex(200f).offset(0.dp, 412.dp).width(1920.dp), contentAlignment = Alignment.TopCenter) {
        Box(Modifier.clip(RoundedCornerShape(40.dp)).background(Color(0xCC000000)).padding(horizontal = 32.dp, vertical = 8.dp)) {
            Txt(b, 28f)
        }
    }
}

// ---------------------------------------------------------------- cards

/** One animated card: arcs to its slot, resizes, rotates and flips. */
@Composable
private fun SpriteCard(sp: Sprite, slot: Slot, selected: Boolean, onClick: (() -> Unit)?) {
    val density = LocalDensity.current.density
    val target = Offset(slot.x, slot.y - if (selected) 26f else 0f)
    var start by remember { mutableStateOf(sp.spawn) }
    var end by remember { mutableStateOf(sp.spawn) }
    var arc by remember { mutableStateOf(0f) }
    val t = remember { Animatable(1f) }
    val w = remember { Animatable(130f) }
    val rot = remember { Animatable(0f) }

    fun pos(): Offset {
        val p = lerp(start, end, t.value)
        return Offset(p.x, p.y - arc * sin(PI.toFloat() * t.value))
    }

    LaunchedEffect(target) {
        start = pos(); end = target
        val far = (end - start).getDistance() > 160f
        arc = if (far) 70f else 0f
        t.snapTo(0f)
        t.animateTo(1f, tween(if (far) 430 else 300, easing = FastOutSlowInEasing))
    }
    LaunchedEffect(slot.w) { w.animateTo(slot.w, tween(350)) }
    LaunchedEffect(slot.rot) { rot.animateTo(slot.rot, tween(300)) }

    val ry by animateFloatAsState(if (sp.faceUp) 0f else 180f, tween(260), label = "flip")
    var focused by remember { mutableStateOf(false) }

    Box(
        Modifier.zIndex(slot.z)
            .offset { val c = pos(); IntOffset((c.x * density).roundToInt(), (c.y * density).roundToInt()) }
            .size(w.value.dp, (w.value * 1.4f).dp)
            .graphicsLayer { rotationZ = rot.value; rotationY = ry; cameraDistance = 14f * density }
            .onFocusChanged { focused = it.isFocused }
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
    ) {
        if (ry <= 90f) CardFace(sp.card, w.value, slot.tint, selected || focused)
        else Box(Modifier.fillMaxSize().graphicsLayer { rotationY = 180f }) { CardBack(w.value) }
    }
}

@Composable
private fun CardFace(card: Card, w: Float, tint: Boolean, highlight: Boolean) {
    val red = card.suit == Suit.HEARTS || card.suit == Suit.DIAMONDS
    val ink = if (red) Color(0xFFB3261E) else Ink
    val shape = RoundedCornerShape((w * .09f).dp)
    Box(
        Modifier.fillMaxSize().shadow(6.dp, shape).clip(shape)
            .background(if (tint) Color(0xFFBFE8B0) else Color(0xFFFBF7EE))
            .then(if (highlight) Modifier.border(4.dp, Gold, shape) else Modifier)
    ) {
        BasicText(
            "${card.rank.label}\n${card.suit.symbol}",
            Modifier.offset((w * .08f).dp, (w * .04f).dp),
            style = TextStyle(color = ink, fontSize = (w * .22f).sp, fontWeight = FontWeight.Bold, lineHeight = (w * .23f).sp, textAlign = TextAlign.Center),
        )
        if (card.rank.order >= 11) {
            Canvas(Modifier.align(Alignment.Center).size((w * .5f).dp, (w * .6f).dp)) { drawFigure(ink) }
        } else {
            BasicText(card.suit.symbol, Modifier.align(Alignment.Center), style = TextStyle(color = ink, fontSize = (w * .5f).sp))
        }
    }
}

/** Simple crowned figure used for J / Q / K. */
private fun DrawScope.drawFigure(ink: Color) {
    val s = size.width / 70f
    val head = Offset(35f * s, 40f * s)
    drawCircle(Color(0xFFF3D9B1), 14f * s, head)
    drawCircle(ink, 14f * s, head, style = Stroke(3f * s))
    val crown = Path().apply {
        moveTo(14f * s, 26f * s); lineTo(20f * s, 8f * s); lineTo(28f * s, 20f * s); lineTo(35f * s, 4f * s)
        lineTo(42f * s, 20f * s); lineTo(50f * s, 8f * s); lineTo(56f * s, 26f * s); close()
    }
    drawPath(crown, Gold)
    drawPath(crown, ink, style = Stroke(3f * s))
    val body = Path().apply { moveTo(8f * s, 84f * s); quadraticBezierTo(35f * s, 52f * s, 62f * s, 84f * s); close() }
    drawPath(body, ink)
}

@Composable
private fun CardBack(w: Float) {
    val shape = RoundedCornerShape((w * .09f).dp)
    Box(
        Modifier.fillMaxSize().shadow(4.dp, shape).clip(shape)
            .background(
                Brush.linearGradient(
                    0f to Color(0xFFB3261E), 0.5f to Color(0xFFB3261E), 0.5f to Color(0xFF8C1A14), 1f to Color(0xFF8C1A14),
                    start = Offset.Zero, end = Offset(24f, 24f), tileMode = TileMode.Repeated,
                )
            )
            .border((w * .035f).coerceAtLeast(2f).dp, Color(0xFFFBF7EE), shape)
    )
}

// ---------------------------------------------------------------- overlays

@Composable
private fun DumpedOverlay(s: TableState) {
    AnimatedVisibility(
        s.showDumped, Modifier.zIndex(250f),
        enter = fadeIn(tween(200)) + scaleIn(initialScale = 0.92f), exit = fadeOut(tween(150)),
    ) {
        val fr = remember { FocusRequester() }
        LaunchedEffect(Unit) { fr.requestFocus() }
        Box(
            Modifier.requiredSize(1920.dp, 1080.dp).background(Color(0xA6000000))
                .clickable(remember { MutableInteractionSource() }, null) { s.showDumped = false }
        ) {
            Column(
                Modifier.offset(300.dp, 230.dp).size(1320.dp, 620.dp)
                    .clip(RoundedCornerShape(20.dp)).background(Color(0xFF1A0710))
                    .border(4.dp, Gold, RoundedCornerShape(20.dp))
                    .pointerInput(Unit) { detectTapGestures { } }
                    .padding(36.dp)
            ) {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Txt("DUMPED CARDS (${s.dumped.size})", 40f, Gold, FontWeight.Black, serif = true)
                    TvButton("CLOSE", Modifier.size(170.dp, 64.dp).focusRequester(fr), active = true) { s.showDumped = false }
                }
                Txt("Oldest first. Gold outline = latest dump.", 22f, modifier = Modifier.padding(top = 6.dp))
                LazyVerticalGrid(
                    GridCells.Adaptive(130.dp), Modifier.weight(1f).padding(top = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp), horizontalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                    items(s.dumped.toList()) { (c, p) ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(110.dp, 154.dp)) { CardFace(c, 110f, false, c == s.dumped.last().first) }
                            Txt(s.names[p], 20f)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChallengeOverlay(vm: TableViewModel) {
    val s = vm.state
    AnimatedVisibility(s.challenge != null, Modifier.zIndex(260f), enter = fadeIn(), exit = fadeOut()) {
        val fr = remember { FocusRequester() }
        LaunchedEffect(Unit) { fr.requestFocus() }
        Box(Modifier.requiredSize(1920.dp, 1080.dp).background(Color(0xB3000000)), contentAlignment = Alignment.Center) {
            Column(
                Modifier.clip(RoundedCornerShape(24.dp)).background(Color(0xFF1A0710))
                    .border(4.dp, Gold, RoundedCornerShape(24.dp)).padding(48.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Txt("${s.names[s.challengeCaller]} calls FIGHT!", 44f, Gold, FontWeight.Black, serif = true)
                Spacer(Modifier.height(12.dp))
                Txt("Challenge, or fold and lose the round?", 28f)
                Spacer(Modifier.height(32.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(32.dp)) {
                    TvButton("CHALLENGE", Modifier.size(300.dp, 80.dp).focusRequester(fr), active = true) { vm.answerChallenge(true) }
                    TvButton("FOLD", Modifier.size(300.dp, 80.dp)) { vm.answerChallenge(false) }
                }
            }
        }
    }
}

@Composable
private fun ResultOverlay(vm: TableViewModel) {
    val s = vm.state
    val r = s.result
    AnimatedVisibility(r != null, Modifier.zIndex(300f), enter = fadeIn(tween(700)), exit = fadeOut()) {
        val fr = remember { FocusRequester() }
        LaunchedEffect(Unit) {
            repeat(10) {
                try { fr.requestFocus(); return@LaunchedEffect } catch (_: Exception) { delay(50) }
            }
        }
        Box(Modifier.requiredSize(1920.dp, 1080.dp).background(Color(0xF2000000)), contentAlignment = Alignment.Center) {
            if (r != null) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Txt("LWRNZ CASINO", 72f, Gold, FontWeight.Black, serif = true, spacing = 12f)
                val why = when (r.kind) {
                    ResultKind.TONGITS -> "Tongits!"
                    ResultKind.FIGHT -> "wins the fight"
                    ResultKind.FIGHT_ALL_FOLDED -> "everyone folded"
                    ResultKind.STOCK_EMPTY -> "lowest hand when the deck ran out"
                }
                Spacer(Modifier.height(16.dp))
                Txt("${s.names[r.winner]} wins: $why", 40f)
                Spacer(Modifier.height(32.dp))
                r.points.forEachIndexed { i, pts ->
                    Row(
                        Modifier.width(900.dp).padding(vertical = 6.dp).clip(RoundedCornerShape(16.dp))
                            .background(if (i == r.winner) Color(0x40F2C14E) else Color(0x59000000)).padding(horizontal = 32.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Txt(s.names[i], 34f, modifier = Modifier.width(300.dp))
                        Txt("Hand points: $pts", 34f)
                        Txt(if (i == r.winner) "WINNER" else "", 34f, Gold, FontWeight.Black)
                    }
                }
                Spacer(Modifier.height(32.dp))
                TvButton("NEXT ROUND", Modifier.size(380.dp, 84.dp).focusRequester(fr), active = true, fontSp = 30f) { vm.newRound() }
            }
        }
    }
}
