package com.example.tongits.game

import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Implemented by the table screen. Each handler plays its animation and
 * returns when it is done, so the game never runs ahead of what is on screen.
 * (For the deal, launch the card flight and delay ~70 ms to get the stagger.)
 */
interface TableUi {
    suspend fun onDealt(player: Int, card: Card)
    suspend fun onDrew(player: Int, card: Card, fromDiscard: Boolean)
    suspend fun onMelded(player: Int, meld: Meld)
    suspend fun onSapawed(player: Int, target: Int, meldIndex: Int, card: Card)
    suspend fun onDiscarded(player: Int, card: Card)
    suspend fun onFightCalled(player: Int, challengers: List<Int>)
    suspend fun onTurnChanged(player: Int)
    suspend fun onGameOver(result: GameResult)

    /** An AI called a fight: does the human challenge (true) or fold (false)? */
    suspend fun askChallenge(caller: Int): Boolean
}

/**
 * Runs both AI opponents. Use a Main-dispatcher scope (viewModelScope) so the
 * engine is only ever touched from one thread.
 */
class GameController(
    private val engine: TongitsEngine,
    private val ui: TableUi,
    private val scope: CoroutineScope,
    private val humanIndex: Int = 0,
    private val thinkMs: Long = 700,
    private val stepMs: Long = 450,
) {
    private var events = Channel<GameEvent>(Channel.UNLIMITED)
    private var pending = AtomicInteger(0)
    private var humanChallenge = false
    private var pump: Job? = null
    private var loop: Job? = null

    init {
        // fightResponder cannot suspend, so the human's answer is collected
        // before an AI's CallFight is applied (see runAiTurn).
        engine.fightResponder = { p ->
            if (engine.players.indexOf(p) == humanIndex) humanChallenge
            else TongitsAi.wantsToChallenge(p)
        }
    }

    fun start(dealer: Int) {
        pump?.cancel(); loop?.cancel()
        // Fresh queue per round, so nothing stale survives a restart.
        val ch = Channel<GameEvent>(Channel.UNLIMITED)
        val pend = AtomicInteger(0)
        events = ch; pending = pend
        engine.listener = { pend.incrementAndGet(); ch.trySend(it) }
        pump = scope.launch {
            for (e in ch) {
                try { dispatch(e) } finally { pend.decrementAndGet() }
            }
        }
        engine.deal(dealer)
        loop = scope.launch { gameLoop() }
    }

    fun stop() { pump?.cancel(); loop?.cancel() }

    /** Called by the table when the human acts. Returns false if illegal. */
    suspend fun submit(action: Action): Boolean {
        if (engine.current != humanIndex) return false
        val ok = engine.apply(action)
        awaitIdle()
        return ok
    }

    private suspend fun gameLoop() {
        while (engine.phase != Phase.GAME_OVER) {
            awaitIdle()
            if (engine.current == humanIndex) delay(100) else runAiTurn(engine.current)
        }
    }

    private suspend fun runAiTurn(i: Int) {
        delay(thinkMs)
        while (engine.phase != Phase.GAME_OVER && engine.current == i) {
            val action = TongitsAi.chooseAction(engine, i)
            if (action is Action.CallFight) {
                // No meld and no secret meld: nothing to challenge with, so you fold without being asked.
                humanChallenge = engine.players[humanIndex].canChallenge && ui.askChallenge(i)
            }
            if (!engine.apply(action)) {
                // Never freeze: fall back to the always-legal move.
                val fallback = if (engine.phase == Phase.DRAW) Action.DrawStock
                else Action.Discard(engine.players[i].hand.first())
                engine.apply(fallback)
            }
            awaitIdle()
            delay(stepMs)
        }
    }

    private suspend fun awaitIdle() {
        while (pending.get() > 0) delay(16)
    }

    // Assumes the GameEvent classes are data classes whose parameters are in
    // the same order the engine constructs them.
    private suspend fun dispatch(e: GameEvent) {
        when (e) {
            is GameEvent.Dealt -> { val (p, c) = e; ui.onDealt(p, c) }
            is GameEvent.Drew -> { val (p, c, d) = e; ui.onDrew(p, c, d) }
            is GameEvent.Melded -> { val (p, m) = e; ui.onMelded(p, m) }
            is GameEvent.Sapawed -> { val (p, t, i, c) = e; ui.onSapawed(p, t, i, c) }
            is GameEvent.Discarded -> { val (p, c) = e; ui.onDiscarded(p, c) }
            is GameEvent.FightCalled -> { val (p, ch) = e; ui.onFightCalled(p, ch) }
            is GameEvent.TurnChanged -> { val (p) = e; ui.onTurnChanged(p) }
            is GameEvent.GameOver -> { val (r) = e; ui.onGameOver(r) }
        }
    }
}
