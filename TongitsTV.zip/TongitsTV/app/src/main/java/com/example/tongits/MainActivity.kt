package com.example.tongits

import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.tongits.ui.TableScreen
import com.example.tongits.ui.TableViewModel

class MainActivity : ComponentActivity() {
    private val vm: TableViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContent { TableScreen(vm, onQuit = { finish() }) }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean =
        if (event.repeatCount == 0 && vm.hotkey(keyCode)) true else super.onKeyDown(keyCode, event)
}
