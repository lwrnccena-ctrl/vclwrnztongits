package com.example.tongits

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.tongits.ui.TableScreen
import com.example.tongits.ui.TableViewModel

class MainActivity : ComponentActivity() {
    private val vm: TableViewModel by viewModels()
    private val handler = Handler(Looper.getMainLooper())
    private var longFired = false
    private val longPress = Runnable { if (vm.fightIfPossible()) longFired = true }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContent { TableScreen(vm, onQuit = { finish() }) }
    }

    /** Holding OK for ~0.6s calls FIGHT; the release is swallowed so it doesn't also click. */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val k = event.keyCode
        if (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (event.repeatCount == 0) { longFired = false; handler.postDelayed(longPress, 600) }
                else if (longFired) return true
            } else if (event.action == KeyEvent.ACTION_UP) {
                handler.removeCallbacks(longPress)
                if (longFired) { longFired = false; return true }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onDestroy() { handler.removeCallbacks(longPress); super.onDestroy() }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean =
        if (event.repeatCount == 0 && vm.hotkey(keyCode)) true else super.onKeyDown(keyCode, event)
}
