package com.example.tongits.game

import kotlin.random.Random

/**
 * Pure Kotlin rules engine (no Android deps). 3 players, the dealer (last round's winner) gets 13 cards,
 * others 12. Turn: draw (stock, or discard if it melds right away) -> meld/sapaw
 * -> discard. Empty hand, or a hand made only of combos after your discard = Tongits.
 * Sapaw is mandatory for the card you dump: you cannot discard a card that fits an exposed meld. Fight or empty stock = lowest hand wins. Sapawing someone's meld stops them from fighting.
 */
class TongitsEngine(
    val players: List<PlayerState>,
    private val rng: Random = Random.Default,
) {
    val stock = ArrayDeque<Card>()
    val discardPile = ArrayDeque<Card>()

    var current = 0
        private set
    var phase = Phase.DRAW
        private set
    var result: GameResult? = null
        private set

    var listener: (GameEvent) -> Unit = {}

    /** Asked for each opponent when someone calls a fight: true = challenge. */
    var fightResponder: (PlayerState) -> Boolean = { false }

    val currentPlayer: PlayerState get() = players[current]
    val topDiscard: Card? get() = discardPile.lastOrNull()

    fun deal(dealer: Int) {
        stock.clear()
        discardPile.clear()
        players.forEach { it.hand.clear(); it.melds.clear(); it.burned = false }
        result = null
        stock.addAll(fullDeck().shuffled(rng))
        val order = (0 until players.size).map { (dealer + it) % players.size }   // dealer is dealt first
        repeat(12) { order.forEach { giveFromStock(it) } }
        giveFromStock(dealer)
        current = dealer
        phase = Phase.ACT // dealer starts by melding/discarding
        listener(GameEvent.TurnChanged(current))
    }

    private fun giveFromStock(p: Int) {
        val c = stock.removeLast()
        players[p].hand.add(c)
        listener(GameEvent.Dealt(p, c))
    }

    /** Returns false if the action is illegal right now (state is unchanged). */
    fun apply(action: Action): Boolean {
        if (phase == Phase.GAME_OVER) return false
        return when (action) {
            is Action.DrawStock -> drawStock()
            is Action.TakeDiscard -> takeDiscard(action.using)
            is Action.MeldCards -> meldCards(action.cards)
            is Action.Sapaw -> sapaw(action)
            is Action.Discard -> discard(action.card)
            is Action.CallFight -> callFight()
        }
    }

    private fun drawStock(): Boolean {
        if (phase != Phase.DRAW) return false
        if (stock.isEmpty()) {
            finish(stockEmptyWinner(), ResultKind.STOCK_EMPTY)
            return true
        }
        val c = stock.removeLast()
        currentPlayer.hand.add(c)
        listener(GameEvent.Drew(current, c, fromDiscard = false))
        phase = Phase.ACT
        return true
    }

    private fun takeDiscard(using: List<Card>): Boolean {
        val top = topDiscard ?: return false
        val me = currentPlayer
        if (phase != Phase.DRAW || using.size < 2 || using.distinct().size != using.size) return false
        if (!me.hand.containsAll(using) || !Meld.isValid(using + top)) return false
        discardPile.removeLast()
        me.hand.removeAll(using.toSet())
        val meld = Meld.of(using + top)
        me.melds.add(meld)
        listener(GameEvent.Drew(current, top, fromDiscard = true))
        listener(GameEvent.Melded(current, meld))
        phase = Phase.ACT
        checkEmptyHand()
        return true
    }

    private fun meldCards(cards: List<Card>): Boolean {
        val me = currentPlayer
        if (phase != Phase.ACT || cards.distinct().size != cards.size) return false
        if (!me.hand.containsAll(cards) || !Meld.isValid(cards)) return false
        me.hand.removeAll(cards.toSet())
        val meld = Meld.of(cards)
        me.melds.add(meld)
        listener(GameEvent.Melded(current, meld))
        checkEmptyHand()
        return true
    }

    private fun sapaw(a: Action.Sapaw): Boolean {
        val me = currentPlayer
        if (phase != Phase.ACT || a.card !in me.hand) return false
        val target = players.getOrNull(a.targetPlayer) ?: return false
        val old = target.melds.getOrNull(a.meldIndex) ?: return false
        if (!old.canSapaw(a.card)) return false
        me.hand.remove(a.card)
        target.melds[a.meldIndex] = Meld.of(old.cards + a.card)
        if (a.targetPlayer != current) target.burned = true // sapawed players can't fight
        listener(GameEvent.Sapawed(current, a.targetPlayer, a.meldIndex, a.card))
        checkEmptyHand()
        return true
    }

    /** Sapaw is mandatory for the card you dump: you can't discard a card that fits an exposed meld. */
    fun mustSapaw(card: Card): Boolean = players.any { t -> t.melds.any { m -> m.canSapaw(card) } }

    private fun discard(card: Card): Boolean {
        val me = currentPlayer
        if (phase != Phase.ACT || mustSapaw(card) || !me.hand.remove(card)) return false
        discardPile.addLast(card)
        listener(GameEvent.Discarded(current, card))
        // Tongits: nothing left, or everything left is already a combo (no need to meld it)
        if (me.hand.isEmpty() || deadwoodPoints(me.hand) == 0) finish(current, ResultKind.TONGITS) else nextTurn()
        return true
    }

    private fun callFight(): Boolean {
        val me = currentPlayer
        if (phase != Phase.DRAW || !me.canFight) return false
        val challengers = players.indices.filter { it != current && players[it].canChallenge && fightResponder(players[it]) }
        listener(GameEvent.FightCalled(current, challengers))
        if (challengers.isEmpty()) {
            finish(current, ResultKind.FIGHT_ALL_FOLDED)
        } else {
            val best = challengers.minByOrNull { players[it].handPoints() }!!
            // Tie goes to the challenger.
            val winner = if (me.handPoints() < players[best].handPoints()) current else best
            finish(winner, ResultKind.FIGHT)
        }
        return true
    }

    private fun checkEmptyHand() {
        val hand = currentPlayer.hand
        if (hand.isEmpty() || deadwoodPoints(hand) == 0) finish(current, ResultKind.TONGITS)
    }

    /** Deck ran out: lowest hand wins, but anyone with no meld (and no secret meld) is burned and cannot win. */
    private fun stockEmptyWinner(): Int {
        val pool = players.indices.filter { players[it].melds.isNotEmpty() || hasSecretMeld(players[it].hand) }.ifEmpty { players.indices.toList() }
        return pool.minByOrNull { players[it].handPoints() }!!
    }

    private fun nextTurn() {
        // Deck is gone: the round ends right away, lowest hand wins (nobody has to draw).
        currentPlayer.burned = false   // a sapaw only stops you fighting on your next turn
        if (stock.isEmpty()) {
            finish(stockEmptyWinner(), ResultKind.STOCK_EMPTY)
            return
        }
        current = (current + 1) % players.size
        phase = Phase.DRAW
        listener(GameEvent.TurnChanged(current))
    }

    private fun finish(winner: Int, kind: ResultKind) {
        val r = GameResult(winner, kind, players.map { it.handPoints() })
        result = r
        phase = Phase.GAME_OVER
        listener(GameEvent.GameOver(r))
    }
}
