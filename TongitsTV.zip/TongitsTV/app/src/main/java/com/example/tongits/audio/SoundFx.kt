package com.example.tongits.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/** Every sound is synthesized here in code: original, and no audio files to add to the repo. */
object SoundFx {
    private const val SR = 22050
    var enabled = true

    private fun n(ms: Int) = SR * ms / 1000

    private fun sine(freq: Float, ms: Int, vol: Float, decay: Float): FloatArray =
        FloatArray(n(ms)) { i -> (sin(2.0 * PI * freq * i / SR) * vol * exp(-decay * i.toDouble() / n(ms))).toFloat() }

    private fun noise(ms: Int, vol: Float, decay: Float, smooth: Float): FloatArray {
        val r = Random(7)
        var y = 0f
        return FloatArray(n(ms)) { i ->
            y += smooth * ((r.nextFloat() * 2f - 1f) - y)
            (y * vol * exp(-decay * i.toDouble() / n(ms))).toFloat()
        }
    }

    private fun mix(vararg parts: Pair<Int, FloatArray>): ShortArray {
        val len = parts.maxOf { n(it.first) + it.second.size }
        val out = FloatArray(len)
        parts.forEach { (at, s) -> val o = n(at); for (i in s.indices) out[o + i] += s[i] }
        return ShortArray(len) { (out[it].coerceIn(-1f, 1f) * 32000f).toInt().toShort() }
    }

    private val dealClip by lazy { mix(0 to noise(90, 0.8f, 6f, 0.3f)) }
    private val drawClip by lazy { mix(0 to noise(120, 0.7f, 4f, 0.25f)) }
    private val flipClip by lazy { mix(0 to sine(1500f, 30, 0.4f, 8f), 0 to noise(25, 0.5f, 8f, 0.6f)) }
    private val discardClip by lazy { mix(0 to noise(70, 0.9f, 7f, 0.5f), 0 to sine(150f, 90, 0.7f, 6f)) }
    private val meldClip by lazy { mix(0 to sine(784f, 260, 0.4f, 5f), 70 to sine(1175f, 300, 0.35f, 5f)) }
    private val clickClip by lazy { mix(0 to sine(900f, 25, 0.35f, 6f)) }
    private val fightClip by lazy { mix(0 to sine(180f, 300, 0.5f, 3f), 0 to sine(185f, 300, 0.4f, 3f)) }
    private val winClip by lazy {
        mix(0 to sine(523f, 260, 0.45f, 4f), 130 to sine(659f, 260, 0.45f, 4f), 260 to sine(784f, 260, 0.45f, 4f), 390 to sine(1047f, 600, 0.5f, 3f))
    }
    private val loseClip by lazy {
        mix(0 to sine(392f, 300, 0.4f, 4f), 220 to sine(330f, 300, 0.4f, 4f), 440 to sine(262f, 600, 0.45f, 3f))
    }

    private fun play(buf: ShortArray) {
        if (!enabled) return
        try {
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(SR)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buf.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(buf, 0, buf.size)
            t.setNotificationMarkerPosition(buf.size - 1)
            t.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(track: AudioTrack) { track.release() }
                override fun onPeriodicNotification(track: AudioTrack) {}
            })
            t.play()
        } catch (e: Exception) {
            // Sound is optional: never crash the game because of audio.
        }
    }

    fun deal() = play(dealClip)
    fun draw() = play(drawClip)
    fun flip() = play(flipClip)
    fun discard() = play(discardClip)
    fun meld() = play(meldClip)
    fun click() = play(clickClip)
    fun fight() = play(fightClip)
    fun win() = play(winClip)
    fun lose() = play(loseClip)
}
