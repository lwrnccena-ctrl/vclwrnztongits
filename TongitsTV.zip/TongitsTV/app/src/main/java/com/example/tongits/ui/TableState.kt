package com.example.tongits.ui

import android.app.Application
import android.content.Context
import android.view.KeyEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tongits.audio.SoundFx
import com.example.tongits.game.*
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

const val START_CHIPS = 9800
const val ANTE = 100   // each player puts this in; 3 players = the 300 pot

/** One meld a pending sapaw could go on, and the order the selected cards are added in. */
class SapawOption(val p: Int, val i: Int, val order: List<Card>)

/** A stream of chips flying between two points (design-space coordinates). */
class ChipBurst(val id: Int, val from: Offset, val to: Offset, val count: Int, val startDelay: Long = 0L) {
    val totalMs: Long get() = startDelay + (count - 1) * 55L + 650L
}

val POT_POS = Offset(1630f, 540f)
/** Where each seat's chips come from / go to: you = balance text, 1 = Rico's avatar, 2 = Bea's avatar. */
fun seatChipPos(p: Int) = when (p) { 0 -> Offset(200f, 1045f); 1 -> Offset(88f, 72f); else -> Offset(1832f, 72f) }

enum class SortMode { BEST, SUITS, RANKS }

/** Where a card currently lives. */
sealed interface Zone {
    data class InHand(val p: Int) : Zone
    data class InMeld(val p: Int, val i: Int) : Zone
    object OnPile : Zone
}

/** One on-screen card. [spawn] is where it first appears (the stock). */
data class Sprite(val card: Card, val zone: Zone, val faceUp: Boolean, val seq: Int, val spawn: Offset)

/** Target position (in a 1920x1080 design space) for a card. */
data class Slot(val x: Float, val y: Float, val w: Float, val z: Float, val rot: Float = 0f, val tint: Boolean = false)

val STOCK_POS = Offset(832f, 449f)
val DISCARD_POS = Offset(976f, 449f)

private val byRank = compareBy<Card>({ it.rank.order }, { it.suit.ordinal })
private val bySuit = compareBy<Card>({ it.suit.ordinal }, { it.rank.order })

class TableState(val human: Int = 0) {
    val names = listOf("You", "AI Rico", "AI Bea")
    val sprites = mutableStateMapOf<Card, Sprite>()
    val melds: List<MutableList<Meld>> = List(3) { mutableStateListOf<Meld>() }
    val dumped = mutableStateListOf<Pair<Card, Int>>()   // oldest first, with who dumped it
    val selected = mutableStateListOf<Card>()
    var sapawChoice by mutableStateOf<List<SapawOption>?>(null)   // set while you pick which meld to sapaw
    val chipFlights = mutableStateListOf<ChipBurst>()
    var burstId = 0
    val fresh = mutableStateListOf<Card>()               // just drawn: shown at the end of your row

    var stockCount by mutableStateOf(52)
    var turn by mutableStateOf(0)
    var phase by mutableStateOf(Phase.DRAW)
    var sort by mutableStateOf(SortMode.BEST)
    var revealed by mutableStateOf(false)                // your hand turned face up and sorted
    var banner by mutableStateOf<String?>(null)
    var challenge by mutableStateOf<CompletableDeferred<Boolean>?>(null)
    var challengeCaller by mutableStateOf(0)
    var result by mutableStateOf<GameResult?>(null)
    var showDumped by mutableStateOf(false)
    var chips by mutableStateOf(START_CHIPS)             // your balance (kept between rounds and launches)
    var round by mutableStateOf(0)
    var pot by mutableStateOf(ANTE * 3)
    var potCarry = 0                                      // Hitter's Pot left over from rounds nobody won by Tongits
    var hitter by mutableStateOf(-1)                     // who is on a hit streak (a win by Tongits or deck-out)
    var hits by mutableStateOf(0)                        // how many hits in a row (2 takes the pot)
    var hitWinner by mutableStateOf(-1)                  // set when the finished round triggered two hits
    var potCarried by mutableStateOf(false)              // the finished round added to the pot instead of paying it out
    var delta by mutableStateOf(0)                       // chips won/lost in the finished round (after the ante)
    var seq = 0
    var justDealt = true

    fun reset() {
        sprites.clear(); melds.forEach { it.clear() }; dumped.clear(); selected.clear(); fresh.clear()
        stockCount = 52; turn = 0; phase = Phase.DRAW; revealed = false; banner = null
        challenge = null; result = null; showDumped = false; seq = 0; justDealt = true; delta = 0; potCarried = false; hitWinner = -1; chipFlights.clear(); sapawChoice = null
    }

    /** On-screen rectangle of one exposed meld (same layout as [slots]). */
    fun meldRect(p: Int, i: Int): Rect {
        val origin = listOf(Offset(56f, 520f), Offset(56f, 236f), Offset(984f, 236f))
        var x = origin[p].x
        for (k in 0 until i) x += 92f + (melds[p][k].cards.size - 1) * 46f + 32f
        val w = 92f + (melds[p][i].cards.size - 1) * 46f
        return Rect(x, origin[p].y, x + w, origin[p].y + 129f)
    }

    /** Your cards that could take the top discard (2-3 of them make a meld with it) - only while you may still draw. */
    fun chowCards(): Set<Card> {
        val top = dumped.lastOrNull()?.first ?: return emptySet()
        if (turn != human || phase != Phase.DRAW || result != null || !revealed) return emptySet()
        val hand = handOf(human).map { it.card }
        val out = HashSet<Card>()
        for (k in 2..3) hand.combinations(k).filter { Meld.isValid(it + top) }.forEach { out.addAll(it) }
        return out
    }

    fun burst(from: Offset, to: Offset, count: Int, startDelay: Long = 0L): ChipBurst {
        val b = ChipBurst(burstId++, from, to, count, startDelay)
        chipFlights.add(b)
        return b
    }

    fun handOf(p: Int): List<Sprite> =
        sprites.values.filter { it.zone == Zone.InHand(p) }.sortedBy { it.seq }

    /** Computes where every card should be right now. Cards animate toward these. */
    fun slots(): Map<Card, Slot> {
        val out = HashMap<Card, Slot>()
        handOf(1).forEachIndexed { i, s -> out[s.card] = Slot(170f + i * 28f, 40f, 56f, i.toFloat()) }
        handOf(2).forEachIndexed { i, s -> out[s.card] = Slot(1350f + i * 28f, 40f, 56f, i.toFloat()) }

        val mine = handOf(human).map { it.card }
        val tail = mine.filter { it in fresh }
        val base = mine.filter { it !in tail }
        fun row(cs: List<Card>) = cs.forEachIndexed { i, c -> out[c] = Slot(240f + i * 80f, 778f, 136f, 10f + i) }
        if (!revealed) {
            row(mine)
        } else when (sort) {
            SortMode.BEST -> {
                val groups = bestMelds(base)
                var x = 240f
                groups.forEach { g ->
                    g.forEachIndexed { k, c -> out[c] = Slot(x + k * 80f, 694f, 136f, 4f + k, tint = true) }
                    x += 136f + (g.size - 1) * 80f + 36f
                }
                val grouped = groups.flatten().toSet()
                row(base.filter { it !in grouped }.sortedWith(byRank) + tail)
            }
            SortMode.SUITS -> row(base.sortedWith(bySuit) + tail)
            SortMode.RANKS -> row(base.sortedWith(byRank) + tail)
        }

        val origin = listOf(Offset(56f, 520f), Offset(56f, 236f), Offset(984f, 236f))
        for (p in 0..2) {
            var x = origin[p].x
            melds[p].forEach { m ->
                m.cards.forEachIndexed { k, c -> out[c] = Slot(x + k * 46f, origin[p].y, 92f, 20f + k) }
                x += 92f + (m.cards.size - 1) * 46f + 32f
            }
        }

        val n = dumped.size
        dumped.forEachIndexed { i, (c, _) ->
            out[c] = when (n - 1 - i) {
                0 -> Slot(976f, 449f, 130f, 30f)
                1 -> Slot(962f, 457f, 130f, 29f, -9f)
                else -> Slot(988f, 445f, 130f, 28f, 7f)
            }
        }
        return out
    }
}

/** Plays one animation per engine event; the controller waits for each to finish. */
class TongitsTableUi(
    private val s: TableState,
    private val onResult: (GameResult) -> Unit = {},
    private val payout: (GameResult) -> Boolean = { false },
) : TableUi {

    private fun put(card: Card, zone: Zone, up: Boolean) {
        val old = s.sprites[card]
        s.sprites[card] = Sprite(card, zone, up, old?.seq ?: s.seq++, old?.spawn ?: STOCK_POS)
    }

    override suspend fun onDealt(player: Int, card: Card) {
        put(card, Zone.InHand(player), false)
        s.stockCount--
        SoundFx.deal()
        delay(70)                                   // deal stagger
    }

    override suspend fun onDrew(player: Int, card: Card, fromDiscard: Boolean) {
        if (fromDiscard) {
            s.dumped.removeAll { it.first == card }
            put(card, Zone.InHand(player), player == s.human)
            delay(300)
        } else {
            put(card, Zone.InHand(player), false)
            s.stockCount--
            SoundFx.draw()
            if (player == s.human) {
                s.fresh.add(card)
                delay(480); SoundFx.flip(); put(card, Zone.InHand(player), true); delay(300)  // arrive, then flip
            } else delay(520)
        }
        if (player == s.human) s.phase = Phase.ACT
    }

    override suspend fun onMelded(player: Int, meld: Meld) {
        val idx = s.melds[player].size
        s.melds[player].add(meld)
        meld.cards.forEach { c -> put(c, Zone.InMeld(player, idx), true); s.selected.remove(c); s.fresh.remove(c) }
        SoundFx.meld()
        delay(600)
    }

    override suspend fun onSapawed(player: Int, target: Int, meldIndex: Int, card: Card) {
        val old = s.melds[target][meldIndex]
        s.melds[target][meldIndex] = Meld.of(old.cards + card)
        put(card, Zone.InMeld(target, meldIndex), true)
        SoundFx.meld()
        s.selected.remove(card); s.fresh.remove(card)
        delay(550)
    }

    override suspend fun onDiscarded(player: Int, card: Card) {
        s.dumped.add(card to player)
        put(card, Zone.OnPile, true)
        SoundFx.discard()
        s.selected.remove(card); s.fresh.remove(card)
        delay(600)
    }

    override suspend fun onFightCalled(player: Int, challengers: List<Int>) {
        val who = if (challengers.isEmpty()) "everyone folded" else challengers.joinToString { s.names[it] } + " challenge"
        s.banner = "${s.names[player]} calls FIGHT: $who"
        SoundFx.fight()
        delay(1600)
    }

    override suspend fun onTurnChanged(player: Int) {
        s.turn = player
        s.fresh.clear()
        if (s.justDealt) {
            s.justDealt = false
            s.phase = Phase.ACT                         // the dealer starts by melding/discarding
            s.banner = "Dealing done"
            delay(500)
            s.handOf(s.human).forEach { sp -> s.sprites[sp.card] = sp.copy(faceUp = true); SoundFx.flip(); delay(50) }
            delay(900)
            s.revealed = true                           // flat row -> sorted rows
            delay(700)
        } else s.phase = Phase.DRAW
        s.banner = if (player == s.human) "YOUR TURN: draw, or take the top discard" else "${s.names[player].uppercase()}'S TURN"
    }

    override suspend fun onGameOver(result: GameResult) {
        s.sprites.values.filter { it.zone is Zone.InHand }.forEach { s.sprites[it.card] = it.copy(faceUp = true) }
        s.revealed = true
        delay(2000)
        if (result.winner == s.human) SoundFx.win() else SoundFx.lose()
        if (payout(result)) {   // only the second hit in a row takes the Hitter's Pot
            val flight = s.burst(POT_POS, seatChipPos(result.winner), 12)   // pot flies to the winner
            delay(flight.totalMs)
        }
        onResult(result)
        s.result = result
    }

    override suspend fun askChallenge(caller: Int): Boolean {
        val d = CompletableDeferred<Boolean>()
        s.challengeCaller = caller
        s.challenge = d
        val answer = d.await()
        s.challenge = null
        return answer
    }
}

class TableViewModel(app: Application) : AndroidViewModel(app) {
    val state = TableState()
    private val prefs = app.getSharedPreferences("tongits", Context.MODE_PRIVATE)
    private val players = listOf(PlayerState("You", true), PlayerState("AI Rico"), PlayerState("AI Bea"))
    private val engine = TongitsEngine(players)
    private val controller = GameController(engine, TongitsTableUi(state, ::settle, ::willPayout), viewModelScope, humanIndex = 0)
    private var dealer = 0   // you start the first round

    init {
        state.chips = prefs.getInt("chips", START_CHIPS)
        state.potCarry = prefs.getInt("pot_carry", 0)
        state.hitter = prefs.getInt("hitter", -1)
        state.hits = prefs.getInt("hits", 0)
        newRound()
    }

    private fun isHit(r: GameResult) = r.kind == ResultKind.TONGITS || r.kind == ResultKind.STOCK_EMPTY

    /** True when this result is the winner's second hit in a row (so it pays out the pot). */
    private fun willPayout(r: GameResult) = isHit(r) && r.winner == state.hitter && state.hits >= 1

    /**
     * Hitter's Pot. A "hit" is a win by Tongits or by the deck running out. Two hits in a row by the
     * same player take the whole pot, which then resets to the 3 antes. Until then nothing is paid
     * out: the pot carries over and the next round's antes are added on top. A fight win or someone
     * else's win breaks the streak but does not reset the pot. The ante was paid when the round started.
     */
    private fun settle(r: GameResult) {
        dealer = r.winner   // the winner deals next: first card, 13 cards, first to dump
        val payout = willPayout(r)
        if (isHit(r)) {
            if (r.winner == state.hitter) state.hits++ else { state.hitter = r.winner; state.hits = 1 }
        } else {
            state.hitter = -1; state.hits = 0
        }
        if (payout) {
            if (r.winner == state.human) { state.chips += state.pot; state.delta = state.pot - ANTE }
            else state.delta = -ANTE
            state.hitWinner = r.winner
            state.hitter = -1; state.hits = 0
            state.potCarry = 0
            state.pot = ANTE * 3
        } else {
            state.delta = -ANTE
            state.potCarried = true
            state.potCarry = state.pot
        }
        prefs.edit().putInt("chips", state.chips).putInt("pot_carry", state.potCarry)
            .putInt("hitter", state.hitter).putInt("hits", state.hits).apply()
    }

    fun newRound() {
        state.reset()
        state.round++
        if (state.chips < ANTE) state.chips = START_CHIPS   // broke: refill
        state.chips -= ANTE
        for (p in 0..2) state.burst(seatChipPos(p), POT_POS, 5, p * 250L)   // everyone antes into the pot
        state.pot = state.potCarry + ANTE * 3   // carried pot + everyone's ante
        prefs.edit().putInt("chips", state.chips).apply()
        controller.start(dealer)
    }

    private fun flash(msg: String) {
        state.banner = msg
        viewModelScope.launch { delay(1800); if (state.banner == msg) state.banner = null }
    }

    private fun act(a: Action) {
        viewModelScope.launch {
            if (controller.submit(a)) state.selected.clear() else flash("That move isn't allowed right now")
        }
    }

    fun toggle(c: Card) { if (!state.selected.remove(c)) state.selected.add(c) }
    fun draw() = act(Action.DrawStock)
    fun fight() {
        val me = players[state.human]
        if (state.turn == state.human && state.phase == Phase.DRAW && state.result == null) {
            if (me.melds.isEmpty()) { flash("You need a meld on the table to start a fight"); return }
            if (me.burned) { flash("Your meld was sapawed - no fighting this turn"); return }
        }
        act(Action.CallFight)
    }

    fun take() {
        if (state.selected.size < 2) flash("Pick 2-3 cards that make a meld with the top discard") else act(Action.TakeDiscard(state.selected.toList()))
    }

    /** Meld / sapaw / discard only work after you draw; say so instead of a vague "not allowed". */
    private fun needsDraw(what: String): Boolean {
        if (state.turn == state.human && state.phase == Phase.DRAW && state.result == null) {
            flash("Draw a card first, then $what"); return true
        }
        return false
    }

    /** Sapaw is mandatory for the card you dump: if the card you picked to discard fits a meld, refuse. */
    private fun selectMandatorySapaw(): Boolean {
        val c = state.selected.singleOrNull() ?: return false
        if (players.any { pl -> pl.melds.any { it.canSapaw(c) } }) {
            flash("That card fits a meld - sapaw it instead of discarding")
            return true   // the card stays selected, so SAPAW works right away
        }
        return false
    }

    fun meld() {
        if (needsDraw("meld")) return
        val cards = state.selected.toList().ifEmpty { bestMelds(players[0].hand).firstOrNull() ?: emptyList() }
        if (cards.isEmpty()) flash("No meld to lay down") else act(Action.MeldCards(cards))
    }

    /** Order in which [sel] can be added one by one to a meld of [base], or null if they don't all fit. */
    private fun sapawOrder(base: List<Card>, sel: List<Card>): List<Card>? {
        var cur = base
        val rem = sel.toMutableList()
        val out = ArrayList<Card>()
        while (rem.isNotEmpty()) {
            val c = rem.firstOrNull { Meld.isValid(cur + it) } ?: return null
            out.add(c); rem.remove(c); cur = cur + c
        }
        return out
    }

    /** Sapaws every selected card onto the first meld that accepts all of them. */
    fun sapaw() {
        if (needsDraw("sapaw")) return
        val sel = state.selected.toList()
        if (sel.isEmpty()) { flash("Select one or more cards to sapaw"); return }
        val options = ArrayList<SapawOption>()
        for ((p, pl) in players.withIndex()) for ((i, m) in pl.melds.withIndex()) {
            val order = sapawOrder(m.cards, sel) ?: continue
            options.add(SapawOption(p, i, order))
        }
        when {
            options.isEmpty() -> flash(if (sel.size == 1) "No meld takes that card" else "Those cards don't all fit one meld")
            options.size == 1 -> runSapaw(options[0])
            else -> state.sapawChoice = options   // more than one meld fits: you choose
        }
    }

    fun chooseSapaw(o: SapawOption) {
        state.sapawChoice = null
        runSapaw(o)
    }

    private fun runSapaw(o: SapawOption) {
        viewModelScope.launch {
            for (c in o.order) if (!controller.submit(Action.Sapaw(c, o.p, o.i))) break
            state.selected.clear()
        }
    }

    fun discard() {
        if (needsDraw("discard")) return
        if (state.turn == state.human && selectMandatorySapaw()) return
        val c = state.selected.singleOrNull()
        if (c == null) flash("Select one card to discard") else act(Action.Discard(c))
    }

    /** Remote number keys: 0 = open/close dumped cards, 1 = cycle sort, 2 draw, 3 take, 4 meld, 5 sapaw, 6 discard. Returns true if handled. */
    fun hotkey(keyCode: Int): Boolean {
        val n = when (keyCode) {
            KeyEvent.KEYCODE_0, KeyEvent.KEYCODE_NUMPAD_0 -> 0
            in KeyEvent.KEYCODE_1..KeyEvent.KEYCODE_6 -> keyCode - KeyEvent.KEYCODE_0
            in KeyEvent.KEYCODE_NUMPAD_1..KeyEvent.KEYCODE_NUMPAD_6 -> keyCode - KeyEvent.KEYCODE_NUMPAD_0
            else -> return false
        }
        val s = state
        if (n == 0) {
            if (s.result == null && s.challenge == null && s.sapawChoice == null) s.showDumped = !s.showDumped
            return true
        }
        if (s.result != null || s.challenge != null || s.showDumped || s.sapawChoice != null) return true
        when (n) {
            1 -> {
                s.sort = when (s.sort) { SortMode.BEST -> SortMode.SUITS; SortMode.SUITS -> SortMode.RANKS; SortMode.RANKS -> SortMode.BEST }
                s.fresh.clear()
            }
            2 -> draw()
            3 -> take()
            4 -> meld()
            5 -> sapaw()
            6 -> discard()
        }
        return true
    }

    /** Long-press OK: call FIGHT, but only when it is actually your draw phase. */
    fun fightIfPossible(): Boolean {
        val s = state
        val ok = s.turn == s.human && s.result == null && s.challenge == null && !s.showDumped &&
            s.revealed && s.phase == Phase.DRAW
        if (ok) fight()
        return ok
    }

    fun answerChallenge(challenge: Boolean) { state.challenge?.complete(challenge) }
}
