package com.example.tongits.ui

import android.view.KeyEvent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tongits.audio.SoundFx
import com.example.tongits.game.*
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class SortMode { BEST, SUITS, RANKS }

/** Where a card currently lives. */
sealed interface Zone {
    data class InHand(val p: Int) : Zone
    data class InMeld(val p: Int, val i: Int) : Zone
    object OnPile : Zone
}

/** One on-screen card. [spawn] is where it first appears (the stock). */
data class Sprite(val card: Card, val zone: Zone, val faceUp: Boolean, val seq: Int, val spawn: Offset)

/** Target position (in a 1920x1080 design space) for a card. */
data class Slot(val x: Float, val y: Float, val w: Float, val z: Float, val rot: Float = 0f, val tint: Boolean = false)

val STOCK_POS = Offset(832f, 449f)
val DISCARD_POS = Offset(976f, 449f)

private val byRank = compareBy<Card>({ it.rank.order }, { it.suit.ordinal })
private val bySuit = compareBy<Card>({ it.suit.ordinal }, { it.rank.order })

class TableState(val human: Int = 0) {
    val names = listOf("You", "AI Rico", "AI Bea")
    val sprites = mutableStateMapOf<Card, Sprite>()
    val melds: List<MutableList<Meld>> = List(3) { mutableStateListOf<Meld>() }
    val dumped = mutableStateListOf<Pair<Card, Int>>()   // oldest first, with who dumped it
    val selected = mutableStateListOf<Card>()
    val fresh = mutableStateListOf<Card>()               // just drawn: shown at the end of your row

    var stockCount by mutableStateOf(52)
    var turn by mutableStateOf(0)
    var phase by mutableStateOf(Phase.DRAW)
    var sort by mutableStateOf(SortMode.BEST)
    var revealed by mutableStateOf(false)                // your hand turned face up and sorted
    var banner by mutableStateOf<String?>(null)
    var challenge by mutableStateOf<CompletableDeferred<Boolean>?>(null)
    var challengeCaller by mutableStateOf(0)
    var result by mutableStateOf<GameResult?>(null)
    var showDumped by mutableStateOf(false)
    var seq = 0
    var justDealt = true

    fun reset() {
        sprites.clear(); melds.forEach { it.clear() }; dumped.clear(); selected.clear(); fresh.clear()
        stockCount = 52; turn = 0; phase = Phase.DRAW; revealed = false; banner = null
        challenge = null; result = null; showDumped = false; seq = 0; justDealt = true
    }

    fun handOf(p: Int): List<Sprite> =
        sprites.values.filter { it.zone == Zone.InHand(p) }.sortedBy { it.seq }

    /** Computes where every card should be right now. Cards animate toward these. */
    fun slots(): Map<Card, Slot> {
        val out = HashMap<Card, Slot>()
        handOf(1).forEachIndexed { i, s -> out[s.card] = Slot(170f + i * 28f, 40f, 56f, i.toFloat()) }
        handOf(2).forEachIndexed { i, s -> out[s.card] = Slot(1350f + i * 28f, 40f, 56f, i.toFloat()) }

        val mine = handOf(human).map { it.card }
        val tail = mine.filter { it in fresh }
        val base = mine.filter { it !in tail }
        fun row(cs: List<Card>) = cs.forEachIndexed { i, c -> out[c] = Slot(240f + i * 80f, 778f, 136f, 10f + i) }
        if (!revealed) {
            row(mine)
        } else when (sort) {
            SortMode.BEST -> {
                val groups = bestMelds(base)
                var x = 240f
                groups.forEach { g ->
                    g.forEachIndexed { k, c -> out[c] = Slot(x + k * 80f, 694f, 136f, 4f + k, tint = true) }
                    x += 136f + (g.size - 1) * 80f + 36f
                }
                val grouped = groups.flatten().toSet()
                row(base.filter { it !in grouped }.sortedWith(byRank) + tail)
            }
            SortMode.SUITS -> row(base.sortedWith(bySuit) + tail)
            SortMode.RANKS -> row(base.sortedWith(byRank) + tail)
        }

        val origin = listOf(Offset(56f, 520f), Offset(56f, 236f), Offset(984f, 236f))
        for (p in 0..2) {
            var x = origin[p].x
            melds[p].forEach { m ->
                m.cards.forEachIndexed { k, c -> out[c] = Slot(x + k * 46f, origin[p].y, 92f, 20f + k) }
                x += 92f + (m.cards.size - 1) * 46f + 32f
            }
        }

        val n = dumped.size
        dumped.forEachIndexed { i, (c, _) ->
            out[c] = when (n - 1 - i) {
                0 -> Slot(976f, 449f, 130f, 30f)
                1 -> Slot(962f, 457f, 130f, 29f, -9f)
                else -> Slot(988f, 445f, 130f, 28f, 7f)
            }
        }
        return out
    }
}

/** Plays one animation per engine event; the controller waits for each to finish. */
class TongitsTableUi(private val s: TableState) : TableUi {

    private fun put(card: Card, zone: Zone, up: Boolean) {
        val old = s.sprites[card]
        s.sprites[card] = Sprite(card, zone, up, old?.seq ?: s.seq++, old?.spawn ?: STOCK_POS)
    }

    override suspend fun onDealt(player: Int, card: Card) {
        put(card, Zone.InHand(player), false)
        s.stockCount--
        SoundFx.deal()
        delay(70)                                   // deal stagger
    }

    override suspend fun onDrew(player: Int, card: Card, fromDiscard: Boolean) {
        if (fromDiscard) {
            s.dumped.removeAll { it.first == card }
            put(card, Zone.InHand(player), player == s.human)
            delay(300)
        } else {
            put(card, Zone.InHand(player), false)
            s.stockCount--
            SoundFx.draw()
            if (player == s.human) {
                s.fresh.add(card)
                delay(480); SoundFx.flip(); put(card, Zone.InHand(player), true); delay(300)  // arrive, then flip
            } else delay(520)
        }
        if (player == s.human) s.phase = Phase.ACT
    }

    override suspend fun onMelded(player: Int, meld: Meld) {
        val idx = s.melds[player].size
        s.melds[player].add(meld)
        meld.cards.forEach { c -> put(c, Zone.InMeld(player, idx), true); s.selected.remove(c); s.fresh.remove(c) }
        SoundFx.meld()
        delay(600)
    }

    override suspend fun onSapawed(player: Int, target: Int, meldIndex: Int, card: Card) {
        val old = s.melds[target][meldIndex]
        s.melds[target][meldIndex] = Meld.of(old.cards + card)
        put(card, Zone.InMeld(target, meldIndex), true)
        SoundFx.meld()
        s.selected.remove(card); s.fresh.remove(card)
        delay(550)
    }

    override suspend fun onDiscarded(player: Int, card: Card) {
        s.dumped.add(card to player)
        put(card, Zone.OnPile, true)
        SoundFx.discard()
        s.selected.remove(card); s.fresh.remove(card)
        delay(600)
    }

    override suspend fun onFightCalled(player: Int, challengers: List<Int>) {
        val who = if (challengers.isEmpty()) "everyone folded" else challengers.joinToString { s.names[it] } + " challenge"
        s.banner = "${s.names[player]} calls FIGHT: $who"
        SoundFx.fight()
        delay(1600)
    }

    override suspend fun onTurnChanged(player: Int) {
        s.turn = player
        s.fresh.clear()
        if (s.justDealt) {
            s.justDealt = false
            s.phase = Phase.ACT                         // the dealer starts by melding/discarding
            s.banner = "Dealing done"
            delay(500)
            s.handOf(s.human).forEach { sp -> s.sprites[sp.card] = sp.copy(faceUp = true); SoundFx.flip(); delay(50) }
            delay(900)
            s.revealed = true                           // flat row -> sorted rows
            delay(700)
        } else s.phase = Phase.DRAW
        s.banner = if (player == s.human) "YOUR TURN: draw, or take the top discard" else "${s.names[player].uppercase()}'S TURN"
    }

    override suspend fun onGameOver(result: GameResult) {
        s.sprites.values.filter { it.zone is Zone.InHand }.forEach { s.sprites[it.card] = it.copy(faceUp = true) }
        s.revealed = true
        delay(2000)
        if (result.winner == s.human) SoundFx.win() else SoundFx.lose()
        s.result = result
    }

    override suspend fun askChallenge(caller: Int): Boolean {
        val d = CompletableDeferred<Boolean>()
        s.challengeCaller = caller
        s.challenge = d
        val answer = d.await()
        s.challenge = null
        return answer
    }
}

class TableViewModel : ViewModel() {
    val state = TableState()
    private val players = listOf(PlayerState("You", true), PlayerState("AI Rico"), PlayerState("AI Bea"))
    private val engine = TongitsEngine(players)
    private val controller = GameController(engine, TongitsTableUi(state), viewModelScope, humanIndex = 0)
    private var dealer = 1

    init { newRound() }

    fun newRound() {
        state.reset()
        controller.start(dealer)
        dealer = (dealer + 1) % players.size
    }

    private fun flash(msg: String) {
        state.banner = msg
        viewModelScope.launch { delay(1800); if (state.banner == msg) state.banner = null }
    }

    private fun act(a: Action) {
        viewModelScope.launch {
            if (controller.submit(a)) state.selected.clear() else flash("That move isn't allowed right now")
        }
    }

    fun toggle(c: Card) { if (!state.selected.remove(c)) state.selected.add(c) }
    fun draw() = act(Action.DrawStock)
    fun fight() = act(Action.CallFight)

    fun take() {
        if (state.selected.size < 2) flash("Pick 2-3 cards that make a meld with the top discard") else act(Action.TakeDiscard(state.selected.toList()))
    }

    fun meld() {
        val cards = state.selected.toList().ifEmpty { bestMelds(players[0].hand).firstOrNull() ?: emptyList() }
        if (cards.isEmpty()) flash("No meld to lay down") else act(Action.MeldCards(cards))
    }

    fun sapaw() {
        val c = state.selected.singleOrNull()
        if (c == null) { flash("Select one card to sapaw"); return }
        for ((p, pl) in players.withIndex()) for ((i, m) in pl.melds.withIndex()) {
            if (m.canSapaw(c)) { act(Action.Sapaw(c, p, i)); return }
        }
        flash("No meld takes that card")
    }

    fun discard() {
        val c = state.selected.singleOrNull()
        if (c == null) flash("Select one card to discard") else act(Action.Discard(c))
    }

    /** Remote number keys: 0 = open/close dumped cards, 1 = cycle sort, 2 draw, 3 take, 4 meld, 5 sapaw, 6 discard. Returns true if handled. */
    fun hotkey(keyCode: Int): Boolean {
        val n = when (keyCode) {
            KeyEvent.KEYCODE_0, KeyEvent.KEYCODE_NUMPAD_0 -> 0
            in KeyEvent.KEYCODE_1..KeyEvent.KEYCODE_6 -> keyCode - KeyEvent.KEYCODE_0
            in KeyEvent.KEYCODE_NUMPAD_1..KeyEvent.KEYCODE_NUMPAD_6 -> keyCode - KeyEvent.KEYCODE_NUMPAD_0
            else -> return false
        }
        val s = state
        if (n == 0) {
            if (s.result == null && s.challenge == null) s.showDumped = !s.showDumped
            return true
        }
        if (s.result != null || s.challenge != null || s.showDumped) return true
        when (n) {
            1 -> {
                s.sort = when (s.sort) { SortMode.BEST -> SortMode.SUITS; SortMode.SUITS -> SortMode.RANKS; SortMode.RANKS -> SortMode.BEST }
                s.fresh.clear()
            }
            2 -> draw()
            3 -> take()
            4 -> meld()
            5 -> sapaw()
            6 -> discard()
        }
        return true
    }

    /** Long-press OK: call FIGHT, but only when it is actually your draw phase. */
    fun fightIfPossible(): Boolean {
        val s = state
        val ok = s.turn == s.human && s.result == null && s.challenge == null && !s.showDumped &&
            s.revealed && s.phase == Phase.DRAW
        if (ok) fight()
        return ok
    }

    fun answerChallenge(challenge: Boolean) { state.challenge?.complete(challenge) }
}
