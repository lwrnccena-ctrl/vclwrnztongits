# Tongits TV

Android TV Tongits game (you vs 2 AI). Kotlin + Jetpack Compose, no art or sound files:
cards are drawn in code and sound effects are synthesized.

## Build with GitHub (no Android Studio needed)
1. Push this folder to a GitHub repo (branch `main`, keep the `.github` folder).
2. **Actions** -> **Build APK** runs on every push (or press *Run workflow*) and builds the **release** APK.
3. Open the finished run and download the artifact **Tongits-apk** (a zip with `app-release.apk`).
4. Install it on the TV: Send Files to TV, a USB stick, or `adb install app-release.apk`.

The release APK is signed with the debug key so it installs right away.

## Controls (remote)
- D-pad moves focus, OK presses. OK on a hand card selects / unselects it.
- DRAW: take from the deck (or OK on the deck). TAKE: select 2-3 cards that make a meld with the top discard, then TAKE.
- MELD: lay down the selected cards (nothing selected = lays down your best combo).
- SAPAW: select one or more cards; they all go onto the first meld that accepts them. Meld, sapaw and discard only work after you draw. DISCARD: select one card. Sapaw is mandatory: you cannot discard while any card in your hand fits a meld on the table.
- FIGHT: hold OK for about half a second at the start of your turn. FIGHT and BEST / SUITS / RANKS are skipped by the D-pad.
- Number keys: 0 opens/closes the dumped cards (the pile is skipped by the D-pad), 1 cycles the sort, 2 DRAW, 3 TAKE, 4 MELD, 5 SAPAW, 6 DISCARD.
- 0 shows every dumped card. Back (or 0 again) closes it.

## Rules added
- If more than one meld can take your sapaw, the fitting melds are highlighted and you pick one with the D-pad + OK (Back cancels).
- Burn: having a meld sapawed stops you fighting on your next turn only; after that turn you can fight again unless you get sapawed again.
- When the deck runs out, anyone with no meld on the table is burned and cannot win; lowest hand among the rest wins.
- Secret meld: four of a kind, or a same-suit run of 5+ (SECRET_RUN_LENGTH in Models.kt), in your hand lets you fight without a meld on the table and keeps you from being burned when the deck runs out. A "SECRET MELD" tag shows under FIGHT.
- Chow hint: while you can still draw, any of your cards that can combine (2-3 cards) with the top discard to take it are tinted light sky blue.
- The player whose turn it is gets a glowing, fading rectangle: blue for opponents, yellow for you.
