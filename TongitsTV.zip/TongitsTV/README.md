# Tongits TV

Android TV Tongits game (you vs 2 AI). Kotlin + Jetpack Compose, no art or sound files:
cards are drawn in code and sound effects are synthesized.

## Build with GitHub (no Android Studio needed)
1. Push this folder to a GitHub repo (branch `main`, keep the `.github` folder).
2. **Actions** -> **Build APK** runs on every push (or press *Run workflow*) and builds the **release** APK.
3. Open the finished run and download the artifact **Tongits-apk** (a zip with `app-release.apk`).
4. Install it on the TV: Send Files to TV, a USB stick, or `adb install app-release.apk`.

The release APK is signed with the debug key so it installs right away.

## Controls (remote)
- D-pad moves focus, OK presses. OK on a hand card selects / unselects it.
- DRAW: take from the deck (or OK on the deck). TAKE: select 2-3 cards that make a meld with the top discard, then TAKE.
- MELD: lay down the selected cards (nothing selected = lays down your best combo).
- SAPAW: select one card, it goes on the first meld that accepts it. DISCARD: select one card.
- FIGHT: hold OK for about half a second at the start of your turn. FIGHT and BEST / SUITS / RANKS are skipped by the D-pad.
- Number keys: 1 cycles the sort, 2 DRAW, 3 TAKE, 4 MELD, 5 SAPAW, 6 DISCARD.
- OK on the discard pile shows every dumped card. Back closes it.
